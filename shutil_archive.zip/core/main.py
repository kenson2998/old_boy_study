print('welcome to my atm.')

def login():
    print('login function.')